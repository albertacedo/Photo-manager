/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad.practica03_client_servlet;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import javax.xml.ws.WebServiceRef;
import ws.Image;
import ws.Practica03WS;
import ws.Practica03WS_Service;


@WebServlet(name = "modificarImagen", urlPatterns = {"/modificarImagen"})
@MultipartConfig()
public class modificarImagen extends HttpServlet {
    
    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/Practica03_WS/Practica03WS.wsdl")
    private Practica03WS_Service service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(true);
        if (session.getAttribute("logged_user") == null) {
            response.sendRedirect("error.jsp");
            return;
        }
        
        String id = request.getParameter("id");
        String title = request.getParameter("title");
        String desc = request.getParameter("desc");
        String kw = request.getParameter("kw");
        String author = request.getParameter("author");
        String cdate = request.getParameter("cdate");
        
        if (id == null || title == null || desc == null || kw == null
                || author == null || cdate == null) {
            RequestDispatcher rd = request.getRequestDispatcher("error.jsp");  
            request.setAttribute("err_msg", "Authoritzation revoked to modify image");
            rd.forward(request, response);
            return;
        }

        boolean success = false;

        Part imgpart = request.getPart("file");

        String extension = "";
        int i = imgpart.getSubmittedFileName().lastIndexOf('.');
        if (i > 0) {
            extension = imgpart.getSubmittedFileName().substring(i+1);
        }
        
        String file_uuid = UUID.randomUUID().toString() + "." + extension;
        String storage_path = File.separator + "tmp" + File.separator + file_uuid;
        
        try (BufferedInputStream bin = new BufferedInputStream(imgpart.getInputStream());
            BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(storage_path, false))) {
            boolean image_mod = false;
            int ch;
            while ((ch = bin.read()) != -1) {
                bout.write(ch);
                image_mod = true;
            }
            file_uuid = image_mod ? file_uuid : null;
            
            int post_id = Integer.parseInt(id);
            title = title.isEmpty() ? null : title;
            desc = desc.isEmpty() ? null : desc;
            kw = kw.isEmpty() ? null : kw;
            author = author.isEmpty() ? null : author;
            cdate = cdate.isEmpty() ? null : cdate;
            
            Image img = new Image();

            img.setId(post_id);
            img.setTitle(title);
            img.setDescription(desc);
            img.setKeywords(kw);
            img.setAuthor(author);
            img.setCaptureDate(cdate);
            img.setFilename(file_uuid);
            
            success = ModifyImage(img) >= 0;
        }
        catch(IOException e) {
            System.err.println(e.getMessage());
            success = false;
        }
        if (success) {
            RequestDispatcher rd = request.getRequestDispatcher("success.jsp");  
            request.setAttribute("success_msg", "Post updated successfully");
            rd.forward(request, response);
        }
        else {
            RequestDispatcher rd = request.getRequestDispatcher("error.jsp");  
            request.setAttribute("err_msg", "Post cant be modified by user");
            rd.forward(request, response);
        }

    }
    
    public int ModifyImage(Image image) {
            Practica03WS port = service.getPractica03WSPort();
            return port.modifyImage(image);
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
